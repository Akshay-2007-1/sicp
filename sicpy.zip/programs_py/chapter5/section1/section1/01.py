def gcd(a, b):
    return a if b == 0 else gcd(b, a % b)
function gcd(a, b) {
    return b === 0 ? a : gcd(b, a % b);
}

print(gcd(20, 12))
