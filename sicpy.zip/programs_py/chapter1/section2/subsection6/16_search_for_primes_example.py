def square(x): return x * x
def smallest_divisor(n):
    return find_divisor(n, 2)

def find_divisor(n, test_divisor):
    return (n if square(test_divisor) > n
            else test_divisor if divides(test_divisor, n)
            else find_divisor(n, test_divisor + 1))

def divides(a, b):
    return b % a == 0
def is_prime(n):
    return n == smallest_divisor(n)
def timed_prime_test(n):
    display(n)
    return start_prime_test(n, get_time())

def start_prime_test(n, start_time):
    return (report_prime(get_time() - start_time) if is_prime(n)
            else False)

def report_prime(elapsed_time):
    display(" *** ")
    display(elapsed_time)
    return True
def search_for_primes(start, times):
    return (
        True if times == 0
        else search_for_primes(start + 1, times)
             if start > 2 and start % 2 == 0
        # if we get true, it's a prime
        else search_for_primes(start + 2, times - 1)
             if timed_prime_test(start)
        else search_for_primes(start + 2, times)
    )
search_for_primes(10000, 3)
# search_for_primes(10000000, 3)
# search_for_primes(10000000000, 3)
