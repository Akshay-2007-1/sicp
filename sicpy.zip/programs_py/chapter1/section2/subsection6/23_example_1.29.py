def is_even(n):
    return n % 2 == 0
def square(x): return x * x
def carmichael(n):
    def expmod(base, exp, m):
        return (1 if exp == 0
                else square(expmod(base, exp // 2, m)) % m if is_even(exp)
                else (base * expmod(base, exp - 1, m)) % m)
    def fermat_test(n, a):
        return expmod(a, n, n) == a
    def iterate(n, i):
        return (True if i == n
                else iterate(n, i + 1) if fermat_test(n, i)
                else False)
    return iterate(n, 2)
print(carmichael(561))
# carmichael(1105)
# carmichael(1729)
# carmichael(2465)
# carmichael(2821)
# carmichael(6601)

# expected: true
