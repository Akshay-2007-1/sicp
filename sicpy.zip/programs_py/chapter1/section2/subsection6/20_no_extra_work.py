def square(x): return x * x
def is_even(n):
    return n % 2 == 0
def fast_expt(b, n):
    return (1 if n == 0
            else square(fast_expt(b, n // 2)) if is_even(n)
            else b * fast_expt(b, n - 1))
def expmod(base, exp, m):
    return (1 if exp == 0
            else square(expmod(base, exp // 2, m)) % m if is_even(exp)
            else (base * expmod(base, exp - 1, m)) % m)
def expmod(base, exp, m):
    return fast_expt(base, exp) % m

print(expmod(4, 3, 5))
