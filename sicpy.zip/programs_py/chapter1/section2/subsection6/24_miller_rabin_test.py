def is_even(n):
    return n % 2 == 0
def square(x): return x * x
def random(n):
    return math_floor(math_random() * n)
def miller_rabin_test(n):
    def expmod(base, exp, m):
        return (1 if exp == 0
                else square(trivial_test(expmod(base, exp // 2, m), m)) % m if is_even(exp)
                else (base * expmod(base, exp - 1, m)) % m)
    def trivial_test(r, m):
        return (r if r == 1 or r == m - 1
                else 0 if square(r) % m == 1
                else r)
    def try_it(a):
        return expmod(a, n - 1, n) == 1
    return try_it(1 + random(n - 1))

def do_miller_rabin_test(n, times):
    return (True if times == 0
            else do_miller_rabin_test(n, times - 1) if miller_rabin_test(n)
            else False)

print(do_miller_rabin_test(104743, 1000))
