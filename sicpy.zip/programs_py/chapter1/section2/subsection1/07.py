def inc(x):
    return x + 1

def dec(x):
    return x - 1
def plus(a, b):
    return b if a == 0 else inc(plus(dec(a), b))

print(plus(4, 5))

# expected: 9
