def A(x, y):
    return (0 if y == 0
            else 2 * y if x == 0
            else 2 if y == 1
            else A(x - 1, A(x, y - 1)))
print(A(2, 4))

# expected: 65536
