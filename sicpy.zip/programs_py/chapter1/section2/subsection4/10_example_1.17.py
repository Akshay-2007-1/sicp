def is_even(n):
    return n % 2 == 0
def fast_expt_iter(a, b, n):
    return (a if n == 0
            else fast_expt_iter(a, b * b, n // 2) if is_even(n)
            else fast_expt_iter(a * b, b, n - 1))

def fast_expt(b, n):
    return fast_expt_iter(1, b, n)
print(fast_expt(2, 3))
