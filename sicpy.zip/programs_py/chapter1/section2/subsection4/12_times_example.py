def times(a, b):
    return 0 if b == 0 else a + times(a, b - 1)
print(times(3, 4))

# expected: 12
