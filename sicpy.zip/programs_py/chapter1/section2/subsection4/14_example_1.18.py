def is_even(n):
    return n % 2 == 0
def double(x):
    return x + x

def halve(x):
    return x // 2

def fast_times(a, b):
    return (a if b == 1
            else 0 if a == 0 or b == 0
            else double(fast_times(a, halve(b))) if is_even(b)
            else a + fast_times(a, b - 1))
print(fast_times(3, 4))

# expected: 12
