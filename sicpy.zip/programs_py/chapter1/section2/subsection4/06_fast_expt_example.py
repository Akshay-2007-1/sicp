def square(x): return x * x
def is_even(n):
    return n % 2 == 0
def fast_expt(b, n):
    return (1 if n == 0
            else square(fast_expt(b, n // 2)) if is_even(n)
            else b * fast_expt(b, n - 1))
print(fast_expt(3, 4))

# expected: 81
