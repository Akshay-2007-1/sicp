# recursive function
def f_recursive(n):
    return (n if n < 3
            else f_recursive(n - 1)
                 + 2 * f_recursive(n - 2)
                 + 3 * f_recursive(n - 3))

print(f_recursive(5))

# expected: 25
