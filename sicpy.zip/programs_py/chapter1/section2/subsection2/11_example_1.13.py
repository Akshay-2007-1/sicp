def pascal_triangle(row, index):
    return (False if index > row
            else 1 if index == 1 or index == row
            else pascal_triangle(row - 1, index - 1)
                 + pascal_triangle(row - 1, index))
print(pascal_triangle(5, 4))

# expected: 4
