print(f_iterative(5))
