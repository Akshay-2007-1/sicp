def count_change(amount):
    return cc(amount, 5)

def cc(amount, kinds_of_coins):
    return (1 if amount == 0
            else 0 if amount < 0 or kinds_of_coins == 0
            else cc(amount, kinds_of_coins - 1)
                 + cc(amount - first_denomination(kinds_of_coins),
                      kinds_of_coins))

def first_denomination(kinds_of_coins):
    return (1 if kinds_of_coins == 1
            else 5 if kinds_of_coins == 2
            else 10 if kinds_of_coins == 3
            else 25 if kinds_of_coins == 4
            else 50 if kinds_of_coins == 5
            else 0)

print(count_change(100))
