def gcd(a, b):
    return a if b == 0 else gcd(b, a % b)
print(gcd(20, 12))

# expected: 4
